from flask import Blueprint, request, jsonify, send_file
from .services import LTEPredictionService_optimised

lte_prediction_op = Blueprint("lte_prediction_optimized", __name__)

service = LTEPredictionService_optimised()


# ==========================================================
# RUN OPTIMIZED PREDICTION
# ==========================================================
@lte_prediction_op.route("/optimized", methods=["POST"])
def run_optimized():

    data = request.get_json()

    required_fields = ["project_id", "radius", "grid_resolution"]

    for field in required_fields:
        if field not in data:
            return jsonify({"error": f"{field} is required"}), 400

    result = service.submit(data)

    return jsonify(result)


# ==========================================================
# CHECK STATUS
# ==========================================================
@lte_prediction_op.route("/status/<job_id>", methods=["GET"])
def status(job_id):

    job = service.get(job_id)

    if not job:
        return jsonify({"error": "Job not found"}), 404

    return jsonify(job)


# ==========================================================
# DOWNLOAD FILE
# ==========================================================
@lte_prediction_op.route("/download", methods=["GET"])
def download():

    file_path = request.args.get("file")

    if not file_path:
        return jsonify({"error": "file path required"}), 400

    return send_file(file_path, as_attachment=True)